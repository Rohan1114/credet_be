import time

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By


class Test_Pytest:

    @pytest.mark.regression
    def test_sum_005(self):
        a = 7
        b = 4
        sum = a + b
        #print(sum)
        if sum == 11:
            assert True
        else:
            assert False

    @pytest.mark.regression
    def test_Credence_006(self):
        headless_option = webdriver.ChromeOptions()
        headless_option.add_argument("headless")
        driver = webdriver.Chrome(options=headless_option)
        driver.get("https://credence.in/")
        time.sleep(2)
        driver.find_element(By.XPATH, "//img[@src='/website/images/enquiry.png']").click()
        l = len(driver.find_elements(By.XPATH, "//div[@class='quickfinder-description gem-text-output']//p//a"))
        #print(l)
        Contact_Number_List =[]
        for r in range(1, l+1):
            Contact_Number = driver.find_element(By.XPATH, "//div[@class='quickfinder-description gem-text-output']//p//a[" +str(r)+ "]").text
            #print(Contact_Number)
            Contact_Number_List.append(Contact_Number)
        #print(Contact_Number_List)
        mb = "+91 95790646580"
        if mb in Contact_Number_List:
            print(Contact_Number_List.index(mb))
            assert True
        else:
            assert False
